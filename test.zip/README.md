# softwareengineeringproject1backend
Readme improvements in v0.0.2